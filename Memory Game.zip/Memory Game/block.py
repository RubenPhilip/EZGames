import pygame
from pygame.sprite import Sprite #For inheritance

class Block(Sprite):
    """Class for default block that inherits from Sprite class [Pygame]"""
    
    def __init__(self, settings, screen, block_color):
        super(Block, self).__init__()
        self.screen = screen
        self.settings = settings

        self.rect = pygame.Rect(0, 0, settings.block_width,
                                settings.block_height)

        #Pass color argument to initialization to determine which of the four
        #Blocks it is
        self.color = block_color

        #Set the coordinates of the block based on color:
        #Yellow is in top left, blue is in top right,
        #Red is in bottom left, green is in bottom right
        if block_color == settings.yellow_dark_block_color or block_color == settings.yellow_light_block_color:
            self.rect.x = 275
            self.rect.y = 75

        if block_color == settings.blue_dark_block_color or block_color == settings.blue_light_block_color:
            self.rect.x = (325 + settings.block_width)
            self.rect.y = 75

        if block_color == settings.red_dark_block_color or block_color == settings.red_light_block_color:
            self.rect.x = 275
            self.rect.y = (125 + settings.block_height)

        if block_color == settings.green_dark_block_color or block_color == settings.green_light_block_color:
            self.rect.x = (325 + settings.block_width)
            self.rect.y = (125 + settings.block_height)

        self.x = float(self.rect.x)

    #Blit block to screen
    def draw_block(self):
        pygame.draw.rect(self.screen, self.color, self.rect)

    #Change color from dark to light, based on current color
    def light_up(self):
        if self.color == self.settings.yellow_dark_block_color:
            self.color = self.settings.yellow_light_block_color
        if self.color == self.settings.blue_dark_block_color:
            self.color = self.settings.blue_light_block_color
        if self.color == self.settings.red_dark_block_color:
            self.color = self.settings.red_light_block_color
        if self.color == self.settings.green_dark_block_color:
            self.color = self.settings.green_light_block_color

    #Change color from light to dark, based on current color
    def darken(self):
        if self.color == self.settings.yellow_light_block_color:
            self.color = self.settings.yellow_dark_block_color
        if self.color == self.settings.blue_light_block_color:
            self.color = self.settings.blue_dark_block_color
        if self.color == self.settings.red_light_block_color:
            self.color = self.settings.red_dark_block_color
        if self.color == self.settings.green_light_block_color:
            self.color = self.settings.green_dark_block_color
