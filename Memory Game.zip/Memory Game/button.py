import pygame.font #Imports pygame.font which which displays "Start Game" with a font and colour

class Play_Button:
    """Create the button that prompts user to start a new game"""

    def __init__(self, settings, screen):
        self.screen = screen
        self.screen_rect = screen.get_rect()

        self.width, self.height = 300, 100
        self.button_color = (255, 255, 255)
        self.text_color = (0, 0, 0)
        self.font = pygame.font.SysFont(None, 48)

        self.rect = pygame.Rect(0, 0, self.width, self.height)
        self.rect.center = self.screen_rect.center

        self.setup_message("Start Game")

    #Format message to display the message with the text colour and the button's colour (displays text/message in this case "Start Game")
    def setup_message(self, message):
        self.msg_image = self.font.render(message, True, self.text_color, self.button_color)
        self.msg_image_rect = self.msg_image.get_rect()
        self.msg_image_rect.center = self.rect.center

    #Draw button with message to the screen
    def draw_button(self):
        self.screen.fill(self.button_color, self.rect)
        self.screen.blit(self.msg_image, self.msg_image_rect)
