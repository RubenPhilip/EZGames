class Game_Stats:
    """Declare a class to be used for game stats such as score and level"""
    
    def __init__(self, settings):
        self.settings = settings
        self.game_active = False
        self.score = 0

        self.incorrect_tries_remaining = 5
        self.level = 1

        self.settings.score = 5

    #Function run when new game starts to reset stats to beginning defaults
    def reset_stats(self):
        self.incorrect_tries_remaining = 5
        self.score = 0
        self.level = 1
        self.settings.score = 5
