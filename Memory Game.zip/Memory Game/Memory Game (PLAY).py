"""
DESCRIPTION

My program was created using pygame as it required necessary components that are only available in pygame and as such I used pygame.
Some other programs like tkinter were lacking the necessary things required for my game and for that reason I felt that using pygame was logical.
In order to construct this program, I used many of the simple concepts such as drawing a shape and adding colour and implemented it into my game in order to help me.
I also went and added things I had learned on my own such as the adding of points but some of the concepts used to make the points section was taught in class.
The program works by the user initiating the game by clicking on “Start” which will appear when the game is run.
Then after a short delay one of the squares will flash (simply become a lighter colour). After the first flash, the user must click on the block(s) that flash(ed).
Each time one extra block will be added in order to make it difficult and challenging. Upon clicking on the correct block, the user will accumulate points.

Note that if a flash seems to be on a block for longer than usual then it means it has flashed twice but seems as if its flashed only once.
Also note that all the python files must be in the same folder then "Memory Game (PLAY)" could be run in order to play the game

"""
import pygame
from time import sleep

"""All additional classes and function files used in game"""
from game_settings import Settings
import functions as gf
from button import Play_Button
from statistics import Game_Stats
from scorekeeper import Score_Keeper
from block import Block

def main_game():
    pygame.init() #Initialize pygame
    game_settings = Settings() #Create an instance of settings
    screen = pygame.display.set_mode(
        (game_settings.screen_width, game_settings.screen_height))
    pygame.display.set_caption("Memory Game By: Ruben")
    start_button = Play_Button(game_settings, screen)
    stats = Game_Stats(game_settings) #Create an instance of statistics
    scoreboard = Score_Keeper(screen, game_settings, stats)

    #Creates yellow, blue, red, and green blocks
    yellow_block = Block(game_settings, screen, game_settings.yellow_dark_block_color)
    blue_block = Block(game_settings, screen, game_settings.blue_dark_block_color)
    red_block = Block(game_settings, screen, game_settings.red_dark_block_color)
    green_block = Block(game_settings, screen, game_settings.green_dark_block_color)

    #Create counter variable to determine when to light up a block
    counter = stats.level

    #Create a timecount variable to prevent sleep(1) from running before the button is no longer on screen
    timecount = 0

    #Create a list of blocks to pass to update_screen() function
    blocks = [yellow_block, blue_block, red_block, green_block]

    #Create empty list for the sequence; created here because it must be initialized before reference,
    #But no values are stored in it until gf.setup_round()
    sequence = []

    #Main game loop
    while True:
        #Call the event tracker in the while loop, and return the counter variable which is used in the lightup sequences
        counter = gf.event_tracker(stats, start_button, counter, sequence, yellow_block, blue_block, red_block, green_block, scoreboard)

        #Only run below if the start game button has been clicked
        if stats.game_active:
            #Allow the lightup to appear on screen for one second before darkening
            if timecount > 0:
                sleep(1)

            #Call lightup check function to make sure all blocks are darkened
            gf.check_for_lightup(game_settings, yellow_block, blue_block, red_block, green_block)

            #Run only if there's a counter for amount of blocks to lightup,
            #And if the while loop, when stats.game_active == True has run at least once.
            if counter > 0 and timecount > 0:
                if counter == stats.level:
                    #Call the setup_round() function, passing stats for level, and returning the list
                    sequence = gf.setup_round(stats)

                    #Create a temporary list to be used for the initial lightup
                    temp_seq = list(sequence)

                #Call light_up_list_round to light up all the blocks in the sequence for the user to click in order.
                gf.light_up_list_round(temp_seq, yellow_block, blue_block, red_block, green_block)

                #Subtract 1 from counter until counter reaches 0
                counter -= 1

            #Make sure the while loop has gone through at least once when game is active
            timecount = 1

        #Keep timecount at 0 to prevent it from becoming 1 before while loop in true has run once
        else:
            timecount = 0

        #Update objects on screen to reflect previous actions and events
        gf.update_screen(screen, game_settings, stats, start_button, scoreboard, blocks)

#Run game
main_game()

"""
REFERENCES

https://pythonprogramming.net/pygame-buttons-part-1-button-rectangle/
https://www.youtube.com/watch?v=OGDJdeiuB5M
https://www.youtube.com/watch?v=3RJx34kGRGk
"""
