import pygame.font

class Score_Keeper:
    """Create a scoreboard to display the score and high score to the screen"""
    
    def __init__(self, screen, settings, stats):
        self.screen = screen
        self.screen_rect = screen.get_rect()
        self.settings = settings
        self.stats = stats

        #                   R   G   B
        self.text_color = (255, 255, 255)
        self.font = pygame.font.SysFont(None, 48)

        self.setup_score(self.stats.score)

    #Convert score to string and format into rect for display
    def setup_score(self, score):
        score_str = format(score)
        self.score_image = self.font.render("Score: " + score_str, True, self.text_color, self.settings.bg_color)

        self.score_rect = self.score_image.get_rect()
        self.score_rect.right = self.screen_rect.right - 20
        self.score_rect.top = 20

    #Display score rects to screen
    def show_score(self):
        self.screen.blit(self.score_image, self.score_rect)
