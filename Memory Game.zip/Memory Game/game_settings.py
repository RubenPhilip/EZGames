class Settings:
    #Makes a class to store game settings - The screen width and height

    def __init__(self):
        self.screen_width = 1200
        self.screen_height = 800
        self.bg_color = (0, 0, 0)
                
        self.block_width = 300
        self.block_height = 300

        #The normal colur of the block (dark) and when it flashes it becomes
        #- the lighter version of that colour which ultimitely stimulates a flash
        self.red_dark_block_color = (150, 0, 0)
        self.red_light_block_color = (250, 0, 0)

        self.green_dark_block_color = (0, 150, 0)
        self.green_light_block_color = (0, 250, 0)
        
        self.blue_dark_block_color = (0, 0, 150)
        self.blue_light_block_color = (0, 0, 250)

        self.yellow_dark_block_color = (150, 150, 0)
        self.yellow_light_block_color = (250, 250, 0)
