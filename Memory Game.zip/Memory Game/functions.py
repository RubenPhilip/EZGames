import pygame
import sys #for sys.exit()
import random
from time import sleep

#Another list used to handle the pattern list in the functions file only
full_list = []

#Start an event checker to be placed in the main while loop in simon.py
#Handles all the functions concerning user input [mouse clicks]
def event_tracker(stats, start_button, counter, sequence, yellow, blue, red, green, scoreboard):
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            sys.exit()
        elif event.type == pygame.MOUSEBUTTONDOWN:
            mouse_x, mouse_y = pygame.mouse.get_pos()
            if not stats.game_active:
                check_start_button(stats, start_button, mouse_x, mouse_y)
                break
            else:
                counter = check_for_user_click(mouse_x, mouse_y, sequence, yellow, blue, red, green, stats, scoreboard, counter)

    return counter

#Checks for user to click on start button, then starts game if clicked on
def check_start_button(stats, start_button, mouse_x, mouse_y):
    clicked_button = start_button.rect.collidepoint(mouse_x, mouse_y)

    if clicked_button and not stats.game_active:
        stats.game_active = True
        stats.reset_stats()

#Function in main while loop in simon.py that blits updated objects to
#The screen, such as the changed color in the blocks when lit up
def update_screen(screen, settings, stats, button, scoreboard, blocks):
    screen.fill(settings.bg_color)

    scoreboard.show_score()

    for block in blocks:
        block.draw_block()

    if not stats.game_active:
        button.draw_button()

    pygame.display.flip()

#Run before the next block in a sequence lights up to darken
def check_for_lightup(settings, yellow, blue, red, green):
    yellow.darken()
    blue.darken()
    red.darken()
    green.darken()

#Creates list of blocks to light up; length based on user's current level
def setup_round(stats):
    current_level = stats.level
    while current_level > 0:
        option = random.randint(0,3)
        full_list.append(option)
        current_level -= 1

    return full_list

#Lights up blocks in a sequence based on the list generated in setup_round()
def light_up_list_round(thelist, yellow, blue, red, green):
    if thelist[0] == 0:
        yellow.light_up()
    if thelist[0] == 1:
        blue.light_up()
    if thelist[0] == 2:
        red.light_up()
    if thelist[0] == 3:
        green.light_up()

    del thelist[0]

#Function to light block, display light, and darken it upon user click
def light_and_darken_onclick(block):
    block.light_up()
    block.draw_block()
    pygame.display.flip()
    sleep(1)
    block.darken()
    block.draw_block()
    pygame.display.flip()

#Function to run when the user clicks on the correct square, calling the stats
#And scoreboard variables to alter the current score
def handle_right_click(stats, scoreboard):
    stats.score += (stats.level * 5)
    scoreboard.setup_score(stats.score)
    scoreboard.show_score()
    pygame.display.flip()

#Function to run if the user clicks on the wrong square in the sequence,
#calling the stats, scoreboard, sequence, and counter variables and returning
#the altered counter variable
def handle_wrong_click(stats, scoreboard, sequence, counter, yellow, blue, red, green):
    stats.game_active = False
    
    sequence[:] = [] #Empty the list at the end of the game to prepare for next game
    full_list[:] = [] #Empty list for same purpose as sequence[]
    stats.level = 1
    counter = stats.level
    stats.score = 0
    scoreboard.setup_score(stats.score) #Reset score to 0 and show new score
    scoreboard.show_score()
    pygame.display.flip()
    
    return counter

"""Block position by sequence:
Yellow corresponds with 0
Blue corresponds with 1
Red corresponds with 2
Green corresponds with 3"""

#Main button click function that handles win and lose and what to return based on input
#Calls all four blocks to handle the user click and the lightup
def check_for_user_click(mouse_x, mouse_y, sequence, yellow, blue, red, green, stats, scoreboard, counter):

    #Only run if all blocks have lit up and the game has communicated the whole pattern to the player
    if counter == 0:

        """Checks the sequence list [containing the pattern by 0,1,2,3]
        To see if the user has clicked on all buttons in the sequence
        Only run if the user clicks on a button while waiting for pattern
        To complete"""
        while len(sequence) > 0:

            """The code in this block will only run as long as the game is waiting
            For the user to click on a block and the user clicks within the
            Right block coordinates"""

            #Compares mouse coordinates with the left, right, top, and bottom ends of the yellow block
            #When the user clicks within the yellow block
            if mouse_x > yellow.rect.left and mouse_x < yellow.rect.right and mouse_y > yellow.rect.top and mouse_y < yellow.rect.bottom:

                """Checks the current position in the pattern: as long as it's
                Equivalent to the yellow id, 0, it's correct"""
                if sequence[0] == 0:

                    """Deletes the current first position in pattern
                    so that the next time the function runs, it will be at
                    position 0 again"""
                    del sequence[0]

                    light_and_darken_onclick(yellow) #Light up the yellow block to indicate it's correct
                    handle_right_click(stats, scoreboard) #Handle the score increase

                    break #End the while loop when done

                else:
                    
                    #Function call to handle an incorrect click, lighting up the correct block and ending the game
                    counter = handle_wrong_click(stats, scoreboard, sequence, counter, yellow, blue, red, green)

                    return counter #End the function completely to prevent from running code after loop
                
            #Compares mouse coordinates with the left, right, top, and bottom ends of the blue block
            #When the user clicks within the blue block
            elif mouse_x > blue.rect.left and mouse_x < blue.rect.right and mouse_y > blue.rect.top and mouse_y < blue.rect.bottom:

                """Checks the current position in the pattern: as long as it's
                Equivalent to the blue id, 1, it's correct"""
                if sequence[0] == 1:

                    """Deletes the current first position in pattern
                    so that the next time the function runs, it will be at
                    position 0 again"""
                    del sequence[0]

                    light_and_darken_onclick(blue) #Light up the blue block to indicate it's correct
                    handle_right_click(stats, scoreboard) #Handle the score increase

                    break #End the while loop when done

                else:
                    
                    #Function call to handle an incorrect click, lighting up the correct block and ending the game
                    counter = handle_wrong_click(stats, scoreboard, sequence, counter, yellow, blue, red, green)

                    return counter #End the function completely to prevent from running code after loop

            #Compares mouse coordinates with the left, right, top, and bottom ends of the red block
            #When the user clicks within the red block
            elif mouse_x > red.rect.left and mouse_x < red.rect.right and mouse_y > red.rect.top and mouse_y < red.rect.bottom:

                """Checks the current position in the pattern: as long as it's
                Equivalent to the red id, 2, it's correct"""
                if sequence[0] == 2:

                    """Deletes the current first position in pattern
                    so that the next time the function runs, it will be at
                    position 0 again"""
                    del sequence[0]

                    light_and_darken_onclick(red) #Light up the red block to indicate it's correct
                    handle_right_click(stats, scoreboard) #Handle the score increase

                    break #End the while loop when done
                
                else:

                    #Function call to handle an incorrect click, lighting up the correct block and ending the game
                    counter = handle_wrong_click(stats, scoreboard, sequence, counter, yellow, blue, red, green)

                    return counter #End the function completely to prevent from running code after loop

            #Compares mouse coordinates with the left, right, top, and bottom ends of the green block
            #When the user clicks within the green block
            elif mouse_x > green.rect.left and mouse_x < green.rect.right and mouse_y > green.rect.top and mouse_y < green.rect.bottom:

                """Checks the current position in the pattern: as long as it's
                Equivalent to the green id, 3, it's correct"""
                if sequence[0] == 3:

                    """Deletes the current first position in pattern
                    so that the next time the function runs, it will be at
                    position 0 again"""
                    del sequence[0]

                    light_and_darken_onclick(green) #Light up the green block to indicate it's correct
                    handle_right_click(stats, scoreboard) #Handle the score increase

                    break #End the while loop when done
                
                else:

                    #Function call to handle an incorrect click, lighting up the correct block and ending the game
                    counter = handle_wrong_click(stats, scoreboard, sequence, counter, yellow, blue, red, green)

                    return counter #End the function completely to prevent from running code after loop

            #If the click is not within one of the blocks, then end the loop immediately
            else:
                break

        #Only runs when the user has successfully clicked on all blocks in the pattern            
        if len(sequence) == 0:
            stats.level += 1 #Keep track of how many patterns the user has completed
            counter = stats.level #Set the amount of blocks to lightup in the pattern to the level
            full_list[:] = [] #Clear the list for the next pattern creation

    """Counter is unchanged if the user hasn't clicked on the full pattern
    when 'if len(sequence) == 0:', that changes the value of counter and
    returns it to the main simon.py file to be used in the pattern creation"""
    return counter
