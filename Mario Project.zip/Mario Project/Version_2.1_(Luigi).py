#Vamsi Gajella
#Taha Khimani

#This section import all modules, defines the display and colors, defines some constants and uploads pitures/sounds
import pygame,random,sys,time,os
from os import path

pygame.init()

display_width = 800
display_height = 600

HW, HH = display_width/2, display_height/2
area = display_width*display_height

os.environ["SDL_VIDEO_WINDOW_POS"] = "50,50"

black = (0,0,0)
white = (255,255,255)
green = (0,200,0)
bright_green = (0,255,0)
red = (200,0,0)
bright_red = (255,0,0)
grey = (207,207,207)
highscore_file = "highscore.txt"

gameDisplay = pygame.display.set_mode((display_width,display_height))
pygame.display.set_caption("Mario Kart Remastered")
clock = pygame.time.Clock()

car_width = 73
graphics = 0
score = -10

carimg = pygame.image.load('Luigi\luigi_straight.png')
carrightimg = pygame.image.load('Luigi\luigi_right_turn.png')
carleftimg = pygame.image.load('Luigi\luigi_left_turn.png')
trackimg = pygame.image.load('Pictures\Track_2.png').convert()
goombaimg= pygame.image.load('Goomba\Vector-goomba.png')
koopaimg = pygame.image.load('Koopa\Vector-koopa.png')
bombimg = pygame.image.load('Bomb\Vector-bomb.png')

koopasound = pygame.mixer.Sound('Koopa\Koopa_crash.wav')
bombsound = pygame.mixer.Sound('Bomb\Bomb_crash.wav')
goombasound = pygame.mixer.Sound('Goomba\Goomba_crash.wav')
gameoversound = pygame.mixer.Sound('Music\Gameover_sound.wav')

goombaspeed = 4
goombax=(random.randint(50, 677))
goombay=(600)
goombawidth=65
goombaheight=65

koopaspeed = 5
koopax = (random.randint(50, 677))
koopay = (600)
koopawidth = 65
koopaheight = 65

bombspeed = 6
bombx=(random.randint(50, 677))
bomby=(600)
bombwidth=65
bombheight=65

road_y = 0

def text_objects(text, font):
    """(str, int) - >
    Renders text and font.
    >>> text_objects(message, Largetext)
    
    """
    
    textSurface = font.render(text, True, white)
    return textSurface, textSurface.get_rect()
    
def display_message(message,x,y):
    """(str, int, int) - >
    Renders text and placement
    >>> display_message('High Score',400,20)
    
    """
    
    Largetext = pygame.font.SysFont("comicsansbold", 60)
    TextSurf, TextRect = text_objects(message, Largetext)
    TextRect.center = (x, y)
    gameDisplay.blit(TextSurf, TextRect)
    pygame.display.update()
    time.sleep(0.1)

def high_score():
    """() - >
    Opens High Score screen
    >>>high_score()
    
    """
    
    os.startfile('High_Score_Screen.py')
    
def small_text_display(msg, x, y):
    """(str, int, int) - >
    Renders text and placement
    >>> small_text_display("Copyright © ATV.Inc 2018", 400, 580)
    
    """
    
    Smalltext = pygame.font.Font("freesansbold.ttf",10)
    textSurf, textRect = text_objects(msg, Smalltext)
    textRect.center = ((x), (y))
    gameDisplay.blit(textSurf, textRect)

def message(message):
    """(str) - >
    Renders a message
    >>> message("Hello")
    
    """
    
    Largetext = pygame.font.SysFont("comicsansms", 30)
    TextSurf, TextRect = text_objects(message, Largetext)
    TextRect.center = ((display_width/2), (display_height/2))
    gameDisplay.blit(TextSurf, TextRect)
    pygame.display.update()
    time.sleep(0.1)

def text_display(msg, x, y):
    """(str, int, int) - >
    Renders text and placement
    >>> text_display(str(highscore),400,250)
    
    """
    
    Smalltext = pygame.font.SysFont("comicsansms", 25)
    textSurf, textRect = text_objects(msg, Smalltext)
    textRect.center = ((x), (y))
    gameDisplay.blit(textSurf, textRect)

def button(msg,x,y,w,h,ic,ac,action=None):
    """(str, int, int, int, int, int, int, bool) - >
    Creates a button at a certain place and gives it inactive and active colors.
    >>> button("<-- Back",50, 20, 100, 50, grey, black,"main_menu")
    
    """
    
    mouse = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()
    if x + w > mouse[0] > x and y + h > mouse[1] > y:
        pygame.draw.rect(gameDisplay, ac, (x, y, w, h))
        if click[0] == 1 and action != None:
            if action == "main_menu":
                main_menu()
                quit()
            elif action == 'play':
                game(goombay,goombax,score,goombaspeed,koopay,koopax,koopaspeed,bomby,bombx,bombspeed,graphics,road_y)
    else:
        pygame.draw.rect(gameDisplay, ic, (x, y, w, h))

    Smalltext = pygame.font.Font("freesansbold.ttf",20)
    textSurf, textRect = text_objects(msg, Smalltext)
    textRect.center = ((x + (w/2)), (y + (h/2)))
    gameDisplay.blit(textSurf, textRect)

def crash(score, sound):
    """(int, file) - >
    Determines the sound as well as the score when the player crashes
    >>> crash(score,koopasound)
    
    """
    
    pygame.mixer.music.stop()
    pygame.mixer.Sound.play(sound)
    gameDisplay.blit(trackimg,(0,0))
    display_message('Game Over!',400,20)
    pygame.mixer.Sound.play(gameoversound)
    message('Your Score: ' + str(score))
    time.sleep(4)  

def scorekeeper(score):
    """(int) - >
    Creates a scorekeeper which displays the high score
    >>> scorekeeper(450)
    
    """
     
    font = pygame.font.SysFont("comicsansms", 25)
    text=font.render('Score '+str(score),True,white)
    gameDisplay.blit(text,(100,500))

def goomba(x,y):
    """(int, int) - >
    Displays an image of an enemy
    >>> goomba(0, 0)
    
    """
     
    gameDisplay.blit(goombaimg,(x,y))

def koopa(x,y):
    """(int, int) - >
    Displays an image of an enemy
    >>> koopa(0, 0)
    
    """
     
    gameDisplay.blit(koopaimg,(x,y))

def bomb(x,y):
    """(int, int) - >
    Displays an image of an enemy
    >>> bomb(0, 0)
    
    """
     
    gameDisplay.blit(bombimg, (x,y))

def right_turn_display(x,y):
    """(int, int) - >
    Displays an image of a right turn
    >>> right_turn_display(0, 0)
    
    """
     
    gameDisplay.blit(carrightimg, (x,y))

def left_turn_display(x,y):
    """(int, int) - >
    Displays an image of a left turn
    >>> left_turn_display(0, 0)
    
    """
     
    gameDisplay.blit(carleftimg, (x,y))

def car_display(x,y):
    """(int, int) - >
    Displays an image of the player car
    >>> car_display(0, 0)
    
    """
     
    gameDisplay.blit(carimg, (x,y))


def game(goombay,goombax,score,goombaspeed,koopay,koopax,koopaspeed,bomby,bombx,bombspeed,graphics,road_y):
    """(float, float, float, int, int, int, int, int, int, int, int, int) - >
    This is the bulk of this screen. All the players controls as well as enemy movement is tracked and displayed.
    >>> game(goombay,goombax,score,goombaspeed,koopay,koopax,koopaspeed,bomby,bombx,bombspeed,graphics,road_y)
    
    """
    
    gameDisplay.fill(black)
    pygame.mixer.music.stop()
    pygame.mixer.music.load('Music\Track_music.wav')
    pygame.mixer.music.play()

    #Here is the start of the screen that prompts the user to get ready
    display_message("Ready?",400,50)
    time.sleep(1)
    display_message("Set",400,300)
    time.sleep(1)
    display_message("Go!",400,550)
    time.sleep(0.5)
    
    x = (display_width * 0.45)
    y = (display_height * 0.8)

    #The highscore is read here. Once the user passes the current high score, the music of the game will change in order to alert the user.
    dir = path.dirname(__file__)
    with open(path.join(dir, highscore_file), 'r') as f:
        try:
            highscore = f.read()
        except:
            highscore = f.read()
    x_change = 0
    
    exit_game = False
    while not exit_game:
        
        #This loop tracks the users key movements and changes the position as well as the graphics of the player according to the movements.
        for event in pygame.event.get():
            
            if event.type == pygame.QUIT:
                exit_game = True

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    x_change = -10
                    graphics = 1
                    
                elif event.key == pygame.K_RIGHT:
                    x_change = 10
                    graphics = 2
    
            elif event.type == pygame.KEYUP:
                if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
                    x_change = 0
                    graphics = 0

        x += x_change
        
        #Here the player is limited within the screen.
        if x < 50:
            x = 50
        elif x > display_width - car_width - 50:
            x = display_width - car_width - 50    

        #Here the track is moved down in as long as the player moves in order for the user to have a feel like they are moving forward.
        rel_y = road_y % trackimg.get_rect().height
        gameDisplay.blit(trackimg, (0,rel_y - trackimg.get_rect().height))
        if rel_y < display_height:
            gameDisplay.blit(trackimg,(0,rel_y))
        road_y += 3

        #The car picture is changed according to what the user is doing.
        if graphics == 0:
            car_display(x,y)
        elif graphics == 1:
            left_turn_display(x,y)
        else:
            right_turn_display(x,y)

        #Here is where all the enemies are being tracked and displayed
        goomba(goombax,goombay)
        goombay += goombaspeed

        koopa(koopax,koopay)
        koopay += koopaspeed

        bomb(bombx, bomby)
        bomby += bombspeed

        #This makes sure the enemies never place in the exact same location
        if koopax == goombax or koopax == bombx or goombax == bombx:
            goomba(goombax,goombay)
            goombay += goombaspeed

            koopa(koopax,koopay)
            koopay += koopaspeed
            
            bomb(bombx, bomby)
            bomby += bombspeed

        #This is the enemies speed. It increases as the user has a higher score.
        if goombay > 600:
            goombay=0
            goombax=(random.randint(50, 677))
            score=score+5
            if (score)%100 == 0:
                goombaspeed = goombaspeed + 2
                koopaspeed = koopaspeed + 2
                bombspeed = bombspeed + 2

        #The collision for the goomba is located here.
        if y<goombay+goombaheight:
            if x>goombax and x<goombax+goombawidth or x+car_width>goombax and x+car_width<goombax+goombawidth:
                if score > int(highscore):                          
                    highscore = score                               
                    with open(path.join(dir, highscore_file), 'w') as f:   
                        f.write(str(score))
                crash(score,goombasound)
                time.sleep(2)
                high_score()
                break

        #Repeat for koopa
        if koopay > 600:
            koopay=0
            koopax=(random.randint(50, 677))
            score=score+5
            if (score)%100 == 0:
                koopaspeed = koopaspeed + 2
                goombaspeed = goombaspeed + 2
                bombspeed = bombspeed + 2

        #Repeat for koopa
        if y<koopay+koopaheight:
            if x>koopax and x<koopax+koopawidth or x+car_width>koopax and x+car_width<koopax+koopawidth:
                if score > int(highscore):                          
                    highscore = score                               
                    with open(path.join(dir, highscore_file), 'w') as f:   
                        f.write(str(score))
                crash(score,koopasound)
                time.sleep(2)
                high_score()
                break
        #Repeat for bomb
        if bomby > 600:
            bomby=0
            bombx=(random.randint(50, 677))
            score=score+5
            if (score)%100 == 0:
                koopaspeed = koopaspeed + 2
                goombaspeed = goombaspeed + 2
                bombspeed = bombspeed + 2

        #Repeat for bomb
        if y<bomby+bombheight:
            if x>bombx and x<bombx+bombwidth or x+car_width>bombx and x+car_width<bombx+bombwidth:
                if score > int(highscore):                          
                    highscore = score                               
                    with open(path.join(dir, highscore_file), 'w') as f:   
                        f.write(str(score))
                crash(score,bombsound)
                time.sleep(2)
                high_score()
                break
        #This makes sure the screen is updated.
        scorekeeper(score)
        pygame.display.update()
        clock.tick(60)

#This loop runs the screen
while True:
    game(goombay,goombax,score,goombaspeed,koopay,koopax,koopaspeed,bomby,bombx,bombspeed,graphics,road_y)
    pygame.quit()
    quit()
