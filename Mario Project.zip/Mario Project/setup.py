#Vamsi Gajella
#Taha Khimani

import os
import sys

#opens cmd prompt and places a command. The command prompt then continues when something is entered
os.system("start cmd /c pip install pygame")
print("Press enter to continue")
input()

#Import pygame and then open the intro screen. If an error occurs open a txt help file.
try:
    import pygame
    os.startfile('Mario_Kart_Remastered_Intro_Screen.py')
except:
    os.startfile('pygame_install.txt')
