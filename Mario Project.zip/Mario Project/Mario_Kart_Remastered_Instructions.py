# Vamsi Gajella
# Taha Khimani

#This section import all modules, defines the display and colors, defines some constants and uploads pitures/sounds
import pygame,random,sys,time,os

pygame.init()

display_width = 800
display_height = 600

gold = (244, 212, 66)
yellow = (247, 243, 0)
white = (255,255,255)
red = (200,0,0)
bright_red = (255,0,0)

gameDisplay = pygame.display.set_mode((display_width,display_height))
pygame.display.set_caption("Mario Kart Remastered")
clock = pygame.time.Clock()

pygame.mixer.music.load('Music\Instructions_music.wav')

instructionimg = pygame.image.load('Pictures\instruction_background_base.png').convert()


def text_objects(text, font):
    """(str, int) - >
    Renders text and font.
    >>> text_objects(message, Largetext)
    
    """
    
    textSurface = font.render(text, True, white)
    return textSurface, textSurface.get_rect()
    
def display_message(message):
    """(str, int, int) - >
    Renders text and placement
    >>> display_message('High Score',400,20)
    
    """
    
    Largetext = pygame.font.SysFont("comicsansbold", 60)
    TextSurf, TextRect = text_objects(message, Largetext)
    TextRect.center = (400), (50)
    gameDisplay.blit(TextSurf, TextRect)
    pygame.display.update()
    time.sleep(0.1)
    
def instruction_background_display(x,y):
    """(int, int) - >
    Renders the background and places it
    >>> instruction_background_display(0,0)
    
    """
    
    gameDisplay.blit(instructionimg, (x,y))

def singleplayer():
    """() - >
    Opens the single player instructions file
    >>> instruc_file()
    
    """
    
    os.startfile('Single_Player_Instructions.py')

def multiplayer():
    """() - >
    Opens the multi-player instructions file
    >>> instruc_file()
    
    """
    
    os.startfile('MultiPlayer_Instructions.py')

def menu():
    """() - >
    Starts the intro screen
    >>>menu()
    
    """
    
    os.startfile('Mario_Kart_Remastered_Intro_Screen.py')

def button(msg,x,y,w,h,ic,ac,action=None):
    """(str, int, int, int, int, int, int, bool) - >
    Creates a button at a certain place and gives it inactive and active colors.
    >>> button("<-- Back",50, 20, 100, 50, grey, black,"main_menu")
    
    """
    
    mouse = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()
    if x + w > mouse[0] > x and y + h > mouse[1] > y:
        pygame.draw.rect(gameDisplay, ac, (x, y, w, h))
        if click[0] == 1 and action != None:
            if action == "singleplayer":
                singleplayer()
            if action == "multiplayer":
                multiplayer()
            if action == "quit":
                menu()
                quit()
                
    else:
        pygame.draw.rect(gameDisplay, ic, (x, y, w, h))

    Smalltext = pygame.font.Font("freesansbold.ttf",20)
    textSurf, textRect = text_objects(msg, Smalltext)
    textRect.center = ((x + (w/2)), (y + (h/2)))
    gameDisplay.blit(textSurf, textRect)

def small_text_display(msg, x, y):
    """(str, int, int) - >
    Renders text and placement
    >>> small_text_display("Copyright © ATV.Inc 2018", 400, 580)
    
    """
    
    Smalltext = pygame.font.Font("freesansbold.ttf",10)
    textSurf, textRect = text_objects(msg, Smalltext)
    textRect.center = ((x), (y))
    gameDisplay.blit(textSurf, textRect)

def instructions():
    """() - >
    This is the bulk of this screen. The music, instruction buttons and the quit button are all displayed
    >>> game_end()
    
    """
    pygame.mixer.music.play()
    start = True
    while start == True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
        instruction_background_display(0,0)
        small_text_display("This game is not affiliated with Nintendo", 400, 570)
        small_text_display("Copyright © ATV.Inc 2018", 400, 580)
        #These buttons connect to different instruction files or to the main menu.
        button("Single Player",200, 150, 150, 50, gold, yellow,"singleplayer")
        button("Multiplayer",500, 150, 150, 50, gold, yellow,"multiplayer")
        button("Back", 350, 250, 150, 50, red, bright_red,"quit")
        display_message('How to Play')

        pygame.display.update()
        clock.tick(60)

#This loop runs the screen
while True:
    instructions()
    pygame.quit()
    quit()
