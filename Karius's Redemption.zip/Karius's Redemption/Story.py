#Talha Ali
#Jan 18th 2019
#ICS4U
#Chapter 1 in story
#https://stackoverflow.com/questions/3720740/pass-variable-on-import
#https://stackoverflow.com/questions/7150998/where-is-module-being-imported-from
import pygame
from pygame.locals import *
def main():
    """main() ->Image
    Plays a series of frames to create a short movie
    >>>main()
    video plays
    """
    pygame.init() #Initializes python                                                                      
    pygame.display.init() 
    
    screensize = (798, 459)

    screen = pygame.display.set_mode((screensize))                                                      

    clock = pygame.time.Clock()
    
    pygame.display.set_caption("Karius's Redemption")
    
    ball = pygame.image.load("download.jpg")
    
    background = pygame.image.load("Story1.png")
    story = 0
    pygame.display.set_icon(ball)
    running = True
    while running:                                                          
        clock.tick(64)
        for event in pygame.event.get():                                        
            if event.type == QUIT:                                                
                pygame.quit()
                running = False
        story += 1
        if story == 300:
            background = pygame.image.load("Story2.png")
        elif story == 500:
            background = pygame.image.load("Story3.png")
        elif story == 800:
            background = pygame.image.load("Story4.png")
        elif story == 900:
            background = pygame.image.load("Story5.png")
        elif story == 1200:
            background = pygame.image.load("Story6.png")
        elif story == 1250:
            background = pygame.image.load("Story7.png")
        elif story == 1300:
            background = pygame.image.load("Story8.png")
        elif story == 1315:
            background = pygame.image.load("Story9.png")
        elif story == 1330:
            background = pygame.image.load("Story10.png")
        elif story == 1345:
            background = pygame.image.load("Story11.png")
        elif story == 1360:
            background = pygame.image.load("Story12.png")
        elif story == 1475:
            background = pygame.image.load("Story13.png")
        elif story == 1490:
            background = pygame.image.load("Story14.png")
        elif story == 1600:
            background = pygame.image.load("Story15.png")
        elif story == 2000:
            background = pygame.image.load("Story16.png")
        elif story == 2500:
            file = open("Choice.txt", 'w')#Open file inorder to read it.
            file.write("0")#Saves the message saved in the file in variable message.
            file.close() #Closes file
            import Karius_Redemption_Menu
            
        
            
            
        screen.blit(background, (0, 0))
        pygame.display.flip()
        
    pygame.quit()                                                                       
    pygame.display.quit()
    
main()
            
