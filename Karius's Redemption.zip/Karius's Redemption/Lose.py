#Talha Ali
#Jan 18th 2019
#ICS4U
#Losing screen in story
import pygame
from pygame.locals import *
def main():
    pygame.init()                                                                      
    pygame.display.init()
    
    screensize = (798, 459)

    screen = pygame.display.set_mode((screensize))                                                      

    clock = pygame.time.Clock()
    
    pygame.display.set_caption("Karius's Redemption")
    
    ball = pygame.image.load("download.jpg")
    
    background = pygame.image.load("lose1.png")
    story = 0
    pygame.display.set_icon(ball)
    running = True
    while running:                                                          
        clock.tick(64)
        for event in pygame.event.get():                                        
            if event.type == QUIT:                                                
                pygame.quit()
                running = False
        story += 1
        if story == 200:
            background = pygame.image.load("lose2.png")
        elif story == 500:
            import Karius_Redemption_Menu
        
            
            
        screen.blit(background, (0, 0))
        pygame.display.flip()
        
    pygame.quit()                                                                       
    pygame.display.quit()
    
main()
            
