#Talha Ali
#Jan 18th 2019
#ICS4U
#This program codes the single player game Karius's Redmeption as well as the story mode
#At first there were 4 different files for the story mode but to improve efficiency, it was reduced into 1 file.
import random
import pygame
from pygame.locals import *
import sys


#_______________________________________________________________________________________________________________________________________________________________    
class Pong(object):
    #This is needed to create are pong/ball object.
    #Inside of this class we have many functions. The first one is: 
#_______________________________________________________________________________________________________________________________________________________________
    def __init__(self, screensize):
    

        self.screensize = screensize
        
        self.centerx = int(screensize[0]*random.choice((0.1, 0.5)))                                         
        self.centery = int(screensize[1]*random.choice((0.1, 0.9)))                                       
    
        
        
        self.radius = 8                                                                                   

        self.rect = pygame.Rect(self.centerx-self.radius,
                                self.centery-self.radius,
                                self.radius*2, self.radius*2)                                                     
        self.color = (100,100,255)


        self.direction = [1,0.5]                                              

        self.speedx = 3
        self.speedy = 5
        

        self.hit_edge_left= False
        self.hit_edge_right= False
        #This function, __init__ is needed to start, initialize and create object. It takes the parameter start because it must act on itself.
        #The next two variables created are, self.center(x and y). They both are set as ints because we are multiplying them by a random value.
        #They both equal to almost the same thing except they differ in one thing. Since, x is dealing with width,  0 assigns the first number in the list,
        #and since y is dealing with height, 1 assigns the 2nd number in the list in variable screensize (We will talk about this variable later on).
        #They also are multiplied by a random number from 0.1 to 0.9 because we want the ball to spawn at a random location in the map. This makes the movement
        #of the ball harder to predict, but x only multiplies to a random number from 0.1 to 0.5. This is because if the program was to randomly multiply it by 0.9,
        #the ball would basically spawn in Karius’s net, making it impossible for him to save. And if it was to randomly generate 6, it would land too close to
        #his net, also making it very hard to save. Then, we created Self.radius which is responsible for creating the radius for our ball.
        #The variable self.rect uses the function pygame.Rect with, self.centerx-self.radius and self.centery-self.radius in its parameter.
        #This refers the top left and right, as we are creating a rectangular hit box around the circle object and will only collide with other objects flat on.
        #Self.radius*2, Self.radius*2 sets the size of the hitbox. Moving on, self.color = (100, 100, 255) contains the RGB value for the colour blue, making our ball
        #blue. Next, we have self.direction. This variable contains a list with 1 and 1, which will make this move right and up, initially, and since it is always
        #moving in angle it will always have a value for both x and y. We made this a list because we want to be able to modify and change these x and y values.
        #We also have a self.speedx and y, which sets the initial speed of our ball, but this will change later on to make the ball movement look more realistic,
        #when hitting objects and to make game harder as it progresses. 
#_______________________________________________________________________________________________________________________________________________________________
    def update(self, karius, bale, defender, attacker, attacker_1, defender_1, defender_2, defender_3, wait, hard, story_number):
        global collision
        
        self.centerx += self.direction [0]*self.speedx
        self.centery += self.direction [1]*self.speedy

        self.rect.center = (self.centerx, self.centery)
        
        if self.rect.top <= 0:
            self.direction[1] = 1
        elif self.rect.bottom >= self.screensize[1]-1:
            self.direction[1] = -1
            
        if self.rect.right >= self.screensize[0]-1:
            self.hit_edge_right = True
        elif self.rect.left <= 0:
            self.hit_edge_left = True

        
        
        if self.rect.colliderect(karius.rect):
            self.direction[0] = -1
            self.direction[1]= random.choice((-5,-4,-3,-2,-1,1,2,3,4,5))
            commentary_number=random.randint(1,5)
            if commentary_number == 1:
                pygame.mixer.music.load("martin_tyler.mp3")
                pygame.mixer.music.play()
            elif commentary_number == 2:
                self.music=pygame.mixer.music.load("save of the season.mp3")
                pygame.mixer.music.play()
            elif commentary_number == 3:
                self.music=pygame.mixer.music.load("stellar save.mp3")
                pygame.mixer.music.play()
            elif commentary_number == 4:
                self.music=pygame.mixer.music.load("amazing save.mp3")
                pygame.mixer.music.play()
            elif commentary_number == 5:
                self.music=pygame.mixer.music.load("spectacular save.mp3")
                pygame.mixer.music.play()

        if self.rect.colliderect(bale.rect):
            self.direction[0] = 1 
            self.direction[1]= random.choice((-5,-4,-3,-2,-1,1,2,3,4,5)) #1,-1 for hard
            self.speedx = 1
        if wait < 15:
            if self.rect.colliderect(attacker.rect):
                if attacker_1.centery >= int(534*0.5):
                    self.direction[0] = 1
                    self.direction[1]= random.choice((-0.5, -0.4, -0.3, -0.2, -0.1))
                    self.speedx= 6
                elif attacker_1.centery <= int(534*0.5):
                    self.direction[0] = 1
                    self.direction[1]= random.choice((0.5, 0.4, 0.3, 0.2, 0.1))
                    self.speedx= 6
                
    
            if self.rect.colliderect(attacker_1.rect):
                if attacker_1.centery >= int(534*0.5):
                    self.direction[0] = -1
                    self.direction[1]= random.choice((-0.5, -0.4, -0.3, -0.2, -0.1))
                    self.speedx= 6
                elif attacker_1.centery <= int(534*0.5):
                    self.direction[0] = -1
                    self.direction[1]= random.choice((0.5, 0.4, 0.3, 0.2, 0.1))
                    self.speedx= 6
        else:
            if story_number == "1" or story_number == "2" or story_number == "3":
                "Now the ball is only kicked towards karius"
            else:
                if self.rect.colliderect(attacker.rect):
                    if attacker.centery >= int(534*0.5):
                        self.direction[0] = 1
                        self.direction[1]= random.choice((-0.5, -0.4, -0.3, -0.2, -0.1))
                        self.speedx= 6
                    elif attacker.centery <= int(534*0.5):
                        self.direction[0] = 1
                        self.direction[1]= random.choice((0.5, 0.4, 0.3, 0.2, 0.1))
                        self.speedx= 6
           
        if self.rect.colliderect(defender) or self.rect.colliderect(defender_3):
            self.speedx= 0.5
            if self.rect.colliderect(defender):
                self.direction[0]=1
            elif self.rect.colliderect(defender_3):
                self.direction[0]=-1
            
            self.direction[1] = 1
        if self.rect.colliderect(defender_1) or self.rect.colliderect(defender_2):
            self.speedx= 0.58
            self.direction[0]=-self.direction[0]
            self.direction[1] = -1
            if self.rect.colliderect(defender_1):
                self.direction[0]=1
            elif self.rect.colliderect(defender_2):
                self.direction[0]=-1
        #The variable self.rect.center contains the value self.centerx, self.centery in a tuple. This ensures the rectangular hitbox is always moving.
        #To confirm if the ball has gone past Karius or Bale or has hit the top or bottom, we use an if statement to check this. It confirms if the top
        #of the rectangle goes past 0, which is the coordinates of the top of our map, if it does it makes the ball come back down. If this does not occur
        #it confirms if the ball has hit the bottom of the map, and if it has, it changes the balls direction making it go on in the opposite way. You might
        #be wondering why up is -1, while down is +1. In pygame,  the coordinates for anything above the center of the map are negative while its the opposite
        #for anything under the center. This is opposite to the graphs we use in real life. The next two if statements do not need to be explained because they
        #perform the same thing as the two if statements we just went over and have the same algorithms but But it sets the variable for hitting the edge as true.
        #This will be explained later on because we need this to make our game end(When it hits either side, the game ends). Our next if statement, use the
        #pygame function self.rectcolliderect with the parameter as Karius because this pygame function is needed to confirm if the ball and karius are in
        #direct contact. If they are it changes the x direction of the ball to opposite of what it was, (similar to our first if statements), and the y to a
        #random number between -5 to 5. This is a random number because we want Karius's saves to have a real life feel to them and real life goalkeeper physics.
        #What I mean is, when Karius saves the ball you wouldn't expect it just deflect back, but go in a random direction just like in real life soccer.
        #This also makes the speed of our ball much slower because, just like in real life soccer when the goalkeeper saves a shot, he deflects it taking some power
        #of it as well. This also solves a problem in our game. Commentary number is chosen to a random number between 1 and 5 because we don’t want our commentator
        #to repeat the same thing over and over again every time Karius’s saves a shot but we want it to have something unique to the save.
        #The same thing occurs with our Bale object but the only different is his sprite changes to a different image because when he collides with the ball,
        #we change his image to him kicking it. The variable story_number is a value taken from the external file "Store.txt",  

#_______________________________________________________________________________________________________________________________________________________________        
            
        
    def render(self, screen):
        pygame.draw.circle(screen, self.color, self.rect.center, self.radius, 0)
        pygame.draw.circle(screen, (0,0,0), self.rect.center, self.radius, 1)
    #All this does is render our ball, and the hitbox onto the screen using pygame function blit.     
#_______________________________________________________________________________________________________________________________________________________________         
class Bale(object):
    def __init__ (self, screensize, story_number):
        self.screensize = screensize

        self.centerx = 15
        self.centery = int(screensize[1]*0.5)
        
        self.height =  25
        
        self.width = 10
        #This code is used to design the enemy team. It is given the name "bale" after the name of the soccer player who humiliated Karius in real life.
        #The same algorithms are used to create our soccer ball. So if this code seems confusing most of it can be explained by reading the comments in the
        #pong class.
#_______________________________________________________________________________________________________________________________________________________________ 
        self.item = pygame.image.load("attacker.png")
        #This piece of code uses a pygame function, to give Bale his image.
#_______________________________________________________________________________________________________________________________________________________________ 
        self.rect = pygame.Rect(0, self.centery-int(self.height*0.5), self.width, self.height)

        self.color = (255, 100, 100)
        if story_number == "1": 
            self.speed = 1
        elif story_number == "2": 
            self.speed = 1.5
        elif story_number == "3": 
            self.speed = 1.6
        else:
            self.speed = 5

    def update(self, pong):
        if pong.rect.top < self.rect.top:
            self.centery -= self.speed
        elif pong.rect.bottom > self.rect.bottom:
            self.centery += self.speed

        self.rect.center = (self.centerx, self.centery)

    def render(self, screen):
        screen.blit(self.item, self.rect)
#The other codes used for making the soccer ball class used the same algorithms, such as collisions, RGB colour values for design, .blit for rendering and
#pygame.image for loading an image. The same codes and algorithms are applied to our Defender and attacker sub classes, aswell as well as our Karius object.
#Therefore they won't be explained further.
#_______________________________________________________________________________________________________________________________________________________________  


class Defender(Bale):
    def __init__(self, screensize, story_number):
        super().__init__(screensize, story_number)
        self.centerx = 400
        self.centery = int(screensize[1]*0.05)
        self.speed = 11
        if story_number=="1":
            self.item = pygame.image.load("barca2.png")
        elif story_number=="2":
            self.item = pygame.image.load("attacker3.png")
    
    def update(self, pong):
        if self.centerx >= 445:
            self.centerx -= self.speed
        elif pong.centerx < self.centerx:
            self.centerx -= self.speed
        elif pong.rect.x > self.centerx:
            self.centerx += self.speed
            

        self.rect.center = (self.centerx, self.centery)
#_______________________________________________________________________________________________________________________________________________________________
class Defender_1(Bale):
    def __init__(self, screensize, story_number):
        super().__init__(screensize, story_number)
        self.centerx = 400
        self.centery = int(screensize[1]*0.9)
        self.speed = 11
        if story_number=="1":
            self.item = pygame.image.load("barca1.png")
        elif story_number=="2":
            self.item = pygame.image.load("attacker3.png")
    
    def update(self, pong):
        if self.centerx >= 445:
            self.centerx -= self.speed
        elif pong.centerx < self.centerx:
            self.centerx -= self.speed
        elif pong.rect.x > self.centerx:
            self.centerx += self.speed
            

        self.rect.center = (self.centerx, self.centery)
#_______________________________________________________________________________________________________________________________________________________________
class Defender_2(Bale):
    def __init__(self, screensize, story_number):
        super().__init__(screensize, story_number)
        self.centerx = 500
        self.centery = int(screensize[1]*0.9)
        self.speed = 11
        self.item = pygame.image.load("team.png")
    
    def update(self, pong):
        if self.centerx <= 431:
            self.centerx += self.speed
        elif pong.centerx < self.centerx:
            self.centerx -= self.speed
        elif pong.rect.x > self.centerx:
            self.centerx += self.speed
            

        self.rect.center = (self.centerx, self.centery)
#_______________________________________________________________________________________________________________________________________________________________
class Defender_3(Bale):
    def __init__(self, screensize, story_number):
        super().__init__(screensize, story_number)
        self.centerx = 500
        self.centery = int(screensize[1]*0.05)
        self.speed = 11
        self.item = pygame.image.load("team1.png")
    
    def update(self, pong):
        if self.centerx <= 431:
            self.centerx += self.speed
        elif pong.centerx < self.centerx:
            self.centerx -= self.speed
        elif pong.rect.x > self.centerx:
            self.centerx += self.speed
            

        self.rect.center = (self.centerx, self.centery)
#_______________________________________________________________________________________________________________________________________________________________
class Attacker(Bale):
    def __init__(self, screensize, story_number):
        super().__init__(screensize, story_number)
        self.centerx = 400
        self.centery = int(screensize[1]*0.3)
        self.speed = 3
        if story_number=="1":
            self.item = pygame.image.load("barca.png")
        elif story_number=="2":
            self.item = pygame.image.load("attacker2.png")
#_______________________________________________________________________________________________________________________________________________________________
class Attacker_1(Bale):
    def __init__(self, screensize, story_number):
        super().__init__(screensize, story_number)
        self.centerx = 500
        self.speed = 3
        self.item = pygame.image.load("team1.png")
#_______________________________________________________________________________________________________________________________________________________________

        
class Karius(object):
    def __init__ (self, screensize):

        self.item = pygame.image.load("goalkeeper.png")
        
        self.screensize = screensize

        self.centerx = screensize[0]-35
        self.centery = int(screensize[1]*0.5)
        
        self.height =  35
        self.width = 10

        self.rect = pygame.Rect(0, self.centery-int(self.height*0.5), self.width, self.height)

        self.color = (100, 255, 100)

        self.speed = 3
        self.direction = 0
    

    def update(self):
        self.centery += self.direction*self.speed

        self.rect.center = (self.centerx, self.centery)
        if self.rect.top < 0:
            self.rect.top = 0
        if self.rect.bottom > self.screensize[1]-1:
            self.rect.bottom = self.screensize[1]-1

    def render(self, screen):
        screen.blit(self.item, self.rect)


#_______________________________________________________________________________________________________________________________________________________________        
def main():
    file = open("Store.txt", 'r')#Open file inorder to read it.
    story_number = file.read()#Saves the message saved in the file in variable message.
    file.close() #Closes file
    


#_______________________________________________________________________________________________________________________________________________________________                                                                               
    pygame.init()                                                                      
    pygame.display.init()
    
    screensize = (878, 534)

    screen = pygame.display.set_mode((screensize))                                                      

    clock = pygame.time.Clock()                                                             

    font = pygame.font.SysFont("Impact", 20)

    saves = 0

    pygame.display.set_caption("Karius's Redemption")

    ball = pygame.image.load("download.jpg")

    background = pygame.image.load("footballfield.jpg")

    pygame.display.set_icon(ball)
    #We first define our function, main, which we are going to execute later in order to run our game. Just like in our main menu code, we used init
    #function initialize pygame, clock function to limit our fps, screen variables to set the height and width of our screen, the images for sprites,
    #backgrounds and screen icon and font variable for choosing font size and font. The algorithms behind these variables have been explained while explaining
    #the main menu code.
#_______________________________________________________________________________________________________________________________________________________________
    wait = 0
    hard = 0
    karius_wins=0
    bale_wins=0
    restart_loop=True
    time=float(90)
    extra_time=0
    extra_time_tracker=0
    last_game = font.render("", True, (0, 0, 0))
    #Here are some new variables created. Karius_wins and bale_wins keep track of how many goals each player has scored. This time we have two loops.
    #A inner nested loop and a main outer loop. Two control these two loops we have created two flag variables, restart_loop and a variable we will
    #introduce in the future. Next, Time, Extra_time and extra_time_tracker, these variables are used to keep track of what time it is, if it is a draw,
    #will it go to extra time and has extra time ended. More will be explained further on. Since, a real game is 90 minutes, we decided our time is going to
    #be 90 seconds. It is also, a float because, to make the time go down by the closest representation of 1 second, we subtract 0.01 and to use decimals we
    #must also use floats. The subtraction by 0.01 is done later in the while loop. Also a variable last_game is created with string value of “Last Win: “.
    #It does not contain anything after the colons because in the beginning of the game there is no winner.
#_______________________________________________________________________________________________________________________________________________________________

    while restart_loop:
        pong = Pong(screensize)
        bale = Bale(screensize, story_number)
        karius = Karius(screensize)
        defender = Defender(screensize, story_number)
        defender_1 = Defender_1(screensize, story_number)
        defender_2 = Defender_2(screensize, story_number)
        defender_3 = Defender_3(screensize, story_number)
        attacker = Attacker(screensize, story_number)
        attacker_1 = Attacker_1(screensize, story_number)
        who_won=0
        if time<=0:
            if bale_wins>karius_wins:
                who_won=1
                
            elif karius_wins>bale_wins:
                who_won=2
                
            else:
                if extra_time_tracker>0:
                    if extra_time==1:
                        extra_time=extra_time+1
                        time=time+30
                        font = pygame.font.SysFont("Impact", 20)
                        last_game = font.render("Tie Game +30 Minutes", True, (0, 0, 0))
                    elif extra_time>1:
                        who_won=3
                    
        
        status='Shameful and Level: Easy'
        running = True
        #First, the while loop runs for the time, restart_loop, is True. The main function of this loop is to keep the game running even when the pong hits either
        #side of map rather than restarting it. The variable who_won is equal to 0 and is used to confirm who has won. It will be explained in a bit.
        #Next, the code confirms if the time is equal to 0, if it is it confirms  does bale have more goals than Karius, if so, who_won is assigned an integer
        #value of 1, otherwise if Karius has more goals than it is assigned integer value of 2. If none of these if statement conditions are met, it goes on to
        #the else statement, which confirms if the game is going to extra time for the first time or second time. If it is the first time, it gives an additional
        #30 seconds to play, if it is the 2nd time, it ends the game as a draw by assigning the variable who_won, with the integer value of 3. Then the status
        #variable is created. This value will change later on as the score increases. It is initially shameful, because that is how Karius’s should have felt in the
        #champions league final, but as he redeems himself, by getting more saves and a higher score, his status changes to different string values such as
        #‘Legendary’, ‘MOTM’...etc. Of course, we haven’t done this yet but we will in our main game loop.
        #Next, running is equal to True, this is the second flag we talked about before. This flag will control the nested while loop.   
#_______________________________________________________________________________________________________________________________________________________________


        while running:                                                          
            clock.tick(64)                                                          
                                                                                     
            for event in pygame.event.get():                                        
                if event.type == QUIT:                                                
                    pygame.quit()
                    running = False
                elif event.type == KEYDOWN:
                    if event.key == K_UP:
                        karius.direction = -1
                        karius.item = pygame.image.load("saving.png")
                    elif event.key == K_DOWN:
                        karius.direction = 1
                        karius.item = pygame.image.load("saving_down.png")
                    elif event.key == K_LSHIFT:
                        karius.speed=5.5
                elif event.type == KEYUP:
                    if event.key == K_UP and karius.direction == -1:
                        karius.direction = 0
                        karius.item = pygame.image.load("goalkeeper.png")
                    elif event.key == K_DOWN and karius.direction == 1:
                        karius.direction = 0
                        karius.item = pygame.image.load("goalkeeper.png")
                    elif event.key == K_LSHIFT and karius.speed==5.5:
                        karius.speed=1
          
            #To continue, we will talk about what we have in this while running loop. Well, first of all, this clock.tick pygame function, which we created the
            #variable for before, limits the fps to 64. Changing this value to a value higher or lower, will make the games frames per second higher or lower as well.
            #Next, we create our events to make sure we don't crash our system by not being able to close our program properly. For event in pygame.event.get(), is
            #calling the sub library of pygame, the pygame.event.get() function, and it grabs all the inputs we do such mouse movements, mouse clicks and mouse
            #strokes, and the for loop runs just like a while loop but runs every content within pygame.event.get(). Next, the program initializes pygame so it stops
            #the program every time the user wants to quit by using the pygame.quit function and making the variable running false, so the main loop no longer runs.
            #The next if statement uses the event function to confirm if any key is being pressed and the nested if confirms if that key is the up arrow key.
            #If it is, it changes the Karius's direction to go up. When the user is pressing up, the sprite of karius also changes to a different image to give it
            #the effect that he's moving. The same thing is done for the next elif, when the user is pressing down but this his direction is 1, which is down.
            #The last elif statement confirms if the user is pressing the left shift key, which is used to increase the speed of Karius. It is basically like a
            #sprinting function in actual fifa games. If that key is pressed karius's speed increases to 3.5 from his old 1.5. The next, if statement confirms if a
            #key is being released after being pressed. If it is, the code then confirms which key it is. If the user is no longer going up or down,
            #the direction is 0 because he is no longer moving and he goes back to his normal stationary image. Similarly, if the sprint key (left shift) is released,
            #his speed goes back down but not to 1.5 but 1. It goes to 1 rather rather than 1.5 because, a person in real life would not be able walk normal after
            #sprinting, but would walk slower than normal.     
#_______________________________________________________________________________________________________________________________________________________________                
            bale.update(pong)
            defender.update(pong)
            defender_1.update(pong)
            defender_2.update(pong)
            defender_3.update(pong)
            attacker.update(pong)
            attacker_1.update(pong)
            karius.update()
            pong.update(karius, bale, defender, attacker, attacker_1, defender_1, defender_2, defender_3, wait, hard, story_number)                                                         
           
            if pong.hit_edge_left:
                karius_wins=karius_wins+1
                running=False
            elif pong.hit_edge_right:
                bale_wins=bale_wins+1
                running=False
            elif pong.rect.colliderect(karius.rect) and story_number!=("1" or "2" or "3"):
                saves=saves+5
                if saves==0:
                    status='Shameful and Level: Easy'
                elif saves>=5 and saves <20:
                    status='MOTM and Level: Medium'
                    hard = 1
                elif saves>20 and saves <40:
                    status='Legendary and Level: Hard'
                    hard = 2
                elif saves>40:
                    status="Ballon D'or and Level: Legend"
                    hard = 3
            elif pong.rect.colliderect(attacker_1.rect) or pong.rect.colliderect(attacker.rect):
                wait+=1
                if wait>= 20:
                    wait=0
            else:
                if story_number == "1" or story_number == "2" or story_number == "3":
                    time=time-0.02
                else:
                    time = time - 0.001
                if time<=0:
                    extra_time_tracker=extra_time_tracker+1
                    extra_time=extra_time+1
                    running=False
#The first eight pygame functions, .update, are responsible for updating each character and ball, as time goes on (as game loops) because there positions
#are constantly changing. Next, the game uses if statements to confirm the pong has hit either the right side, which results in the game restarting, as
#the main game function is executed from the beginning. It works just like a loop. The third if statement is suppose to confirm if Karius, and the ball are
#in contact or if Karius has made a save. If so, 1 point gets added to his score, but sometimes they are contact for more than one tick, which results in more
#than one 1 point being added to score per save. Moving on, we have the status and difficulty algorithms we mentioned earlier. If his score is 0, his status will
#be shameful, until his save tally is between 5 and 10, which gives him a man of the match award. Then, if somehow he gets his save tally between 10 and 15, he
#will be a legendary goalkeeper and if he makes over 15 saves in this champions league final, he will deserve a Ballon D’or. This makes Bale furious, so bales speed
#increases with the speed of the ball, making the difficulty of the game harder. The last two variables, difficulty and text are used to render the score, and Karius
#status on to the screen. The rendering does not actually occur here, but will occur later on with a pygame function which uses the help of these two variables.
#It helps it by determining there font, colour and string input. Finally time is subtracted by -0.001 in order to make the time go from 90 to 0, just like in a real
#soccer game.

#_______________________________________________________________________________________________________________________________________________________________                

            
            
                
           
            if story_number == "1":
                score = font.render("Barcelona"+str(bale_wins) + "-" + str(karius_wins)+" Liverpool", True, (0, 0, 0))
                time_left = font.render("Time Remaining:  "+str(int(time)), True, (0, 0, 0))
                difficulty = font.render("", True, (0, 0, 255))
                text = font.render("", True, (0, 0, 0))
            elif story_number == "2":
                score = font.render("Dortmund"+str(bale_wins) + "-" + str(karius_wins)+" Liverpool", True, (0, 0, 0))
                time_left = font.render("Time Remaining:  "+str(int(time)), True, (0, 0, 0))
                difficulty = font.render("", True, (0, 0, 255))
                text = font.render("", True, (0, 0, 0))
            elif story_number == "3":
                score = font.render("Real Madrid"+str(bale_wins) + "-" + str(karius_wins)+" Liverpool                                      Champions League Final", True, (0, 0, 0))
                time_left = font.render("Time Remaining:  "+str(int(time)), True, (0, 0, 0))
                difficulty = font.render("", True, (0, 0, 255))
                text = font.render("", True, (0, 0, 0))
            else:
                difficulty = font.render("Status: "+str(status), True, (0, 0, 255))
                text = font.render("Score: "+str(saves), True, (0, 0, 0))
                score = font.render("Training Mode", True, (0, 0, 0))
                time_left = font.render("Time Remaining:  "+str(int(time)), True, (0, 0, 0))
                
            if who_won == 1:
                import Lose
                break
            elif who_won ==2:
                if story_number == "1":
                    import Story_Mode_3
                    
                elif story_number == "2":
                    import Story_Mode_5
                    
                elif story_number == "3":
                    import Story_Mode_7
                    
                
                    
            elif who_won ==3:
                font = pygame.font.SysFont("Impact", 20)
                last_game = font.render("Tied! Game will be played again!", True, (0, 0, 0))
                time=90
                karius_wins=0
                bale_wins=0
                extra_time=0
                extra_time_tracker=0
                running = False
#_______________________________________________________________________________________________________________________________________________________________
            
            screen.fill((100,100,100))
            screen.blit(background, (0, 0))
            screen.blit(score, (200,10))
            screen.blit(time_left, (0,10))
            screen.blit(last_game, (550,30))
            screen.blit(difficulty, (575,10))
            screen.blit(text, (500,10))
            

            

            bale.render(screen)
            defender.render(screen)
            defender_1.render(screen)
            defender_2.render(screen)
            defender_3.render(screen)
            attacker.render(screen)
            attacker_1.render(screen)
            karius.render(screen)
            pong.render(screen)
            
            pygame.display.flip()                                                               
        
    
    pygame.quit()                                                                       
    pygame.display.quit()

main()
            
