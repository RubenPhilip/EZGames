#Talha Ali
#January 18th 2019
#ICS3UR
#This program is the main menu for Karius's Redemption
#The comment format is as follows: The comments explain the block of code before it.
import pygame 
from pygame.locals import * 
import sys       
#The pygame library allows us to use graphics and use events.
#This block of code imports the pygame library as well as the locals, pygame sub library, which particularly allows us to use events.


game = True 

#____________________________________________________________________________________________________________________________________________________________________
pygame.init()                                                                                                             
pygame.mixer.init()                                                                                                 
width = 1280                                                                                                            
height = 720                                                                                                 
updater = pygame.time.Clock()                                                                                                   
screen = pygame.display.set_mode((width, height))

#This block of code, first sets variable game with boolean value of True, which will eventually allow us to control the main game loop.
#Next, it initializes pygame with the function pygame.init(), which works exactly like a real function and executes all the code within pygame.init().
#Similarly, we have pygame.mixer.init(), which initializes the pygame audio module and this allows us to use the loading and playback of any sound/music.
#We then set variable width with an integer value of 1280, and, height with an integer value of 720. These, variables are used in another variable, called screen,
#which uses the pygame function pygame.display.set_mode() with parameters, width and height in a tuple. This will be our screen and we will be drawing on this to
#make our game. Inside of our variable screen, the pygame function makes the screen that has a width that is 1280 pixels wide and a height that is 720 pixels tall. 

#____________________________________________________________________________________________________________________________________________________________________
pygame.display.set_caption("Karius's Redemption")                                                                     
icon=pygame.image.load("download.jpg")                                                                                        
pygame.display.set_icon(icon)


#Next, the function, pygame.display.set_caption(), contains the value “Karius’s Redemption” in a tuple. This basically creates the title of our screen/tab.
#Similarly, it creates a variable icon, with function pygame.image.load(), that contains the value “download.jpg” in a tuple. This imports image named download,
#which will be used as our icon for the screen/tab. Finally, the function pygame.display.set_icon(icon) displays the icon on the top left of our screen.
#For our game, the icon is a soccer ball. 
#____________________________________________________________________________________________________________________________________________________________________
red = (200,0,0)
green = (0,200,0)
bright_red = (255,0,0)
bright_green = (0,255,0)


#This block of code contains numerous variables named after colours because they contain the RGB values for each colour.
#For example 200,0,0 is equal to red and is the value of the variable red. These colours will be used to design the buttons for user inputs.
 
#____________________________________________________________________________________________________________________________________________________________________

def button(msg,x,y,w,h,ic,ac,Choice,action=None):
    
    mouse = pygame.mouse.get_pos()                                  
    click = pygame.mouse.get_pressed()                              
    
    if x+w > mouse[0] and x and y+h > mouse[1] > y:                 
        pygame.draw.rect(screen, ac, (x,y,w,h))                             
        if click[0] == 1 and action != None:                            
            if action == "play":
                if Choice == "0":
                    file = open("Choice.txt", 'w')#Open file inorder to read it.
                    file.write("1")#Saves the message saved in the file in variable message.
                    file.close() #Closes file
                    
                    main()
                if Choice == "1":
                    file = open("Choice.txt", 'w')#Open file inorder to read it.
                    file.write("2")#Saves the message saved in the file in variable message.
                    file.close() #Closes file
                    
                    main()
                if Choice == "2":
                    
                    import Story_Mode_Level
                
                
                
                
                
                
                
            if action == "quit":
                if Choice == "0":
                    print("Thx for playing!")
                    pygame.quit()
                    quit()
                if Choice == "1":
                    import player_2
                if Choice == "2":
                    file = open("Store.txt", 'w')#Open file inorder to read it.
                    file.write("0")#Saves the message saved in the file in variable message.
                    file.close() #Closes file
                    
                    import Story_full
                
    else:
        pygame.draw.rect(screen, ic, (x,y,w,h))                                 
    newfont = pygame.font.SysFont("freesansbold.ttf", 25)                   
    newtext = newfont.render(msg+str(str(" ")), True, (0, 0, 0))                           
    screen.blit(newtext, ((x+(w/2)), (y+(h/2))))

#This block of code will be used to design our button and user inputs. A function button is created with the parameters msg, x, y, h, ic, ac , action=None in a tuple.
#Everything indented within the function will be executed every time this function is called on. First, it creates variable mouse, which contains pygame function
#pygame.mouse.get_pos(). This function is used to find the position of the users mouse. Next, variable click is created which includes pygame function,
#pygame.mouse.get_pressed(). This function is used to see if the mouse is being pressed. The first if statement is used to confirm if mouse has hovered over button.
#If it has, it places another block with a lighter colour on top of the button square to make the button look lighter. Then, if mouse is clicked, and button for play
#is selected, it imports, the next python file we will look through, character_option, which is used to determine if user wants to play single player or multiplayer.
#But if the mouse is clicked on button for quit, the function pygame.quit() is executed and quit(), which stops the program and exits it.
#Otherwise, if mouse has not hovered over button, none of the above code mentioned occurs, and normal buttons are displayed. The next variables newfont, and
#nextext are used to determine font size, font and what each button will say. The if statements and file io are used to increase efficiency as it writes a number to
#a file signifying where each button press should take the user to. This improves efficiency as 5 different files were created at first for the main menu, now it
#using file io, by storing a number in an external file, the main menu is reduced to one file.
    
def main():
#____________________________________________________________________________________________________________________________________________________________________    
    file = open("Choice.txt", 'r')#Open file inorder to read it.
    Choice = file.read()#Saves the message saved in the file in variable message.
    file.close() #Closes file
    #This is done to create efficiency. At first we had 3 different menu's, one for choosing, whether to start the game or quit, the second for choosing, one player,
    #or two player, and the last menu file for choosing story mode or training mode. To remove efficiency, we saved a number corresponding to each mode, in an
    #external file. This number is responsible for changing the background of this main menu file and changing the buttons making it look like as if a new file
    #has been opened. 
#____________________________________________________________________________________________________________________________________________________________________    
    intro = True
    if Choice == "0":
        menuback = pygame.image.load("MAINMENU.jpg")
    elif Choice == "1":
        menuback = pygame.image.load("Liverpool_Won.jpg")
    elif Choice == "2":
        menuback = pygame.image.load("Background.png")
    #The variable menuback, is equal to, the image, MAINMENU.jpg, loaded by pygame function, pygame.image.load. This variable is responsible for loading
    #the background for our main menu. For our game, the background is a picture of Karius and Bale made on photoshop by me. (Background changes as a button is
    #pressed)
#____________________________________________________________________________________________________________________________________________________________________
    while intro:
        for event in pygame.event.get():
            
            if event.type == pygame.QUIT or (event.type == KEYDOWN and event.key == K_ESCAPE):                     
                pygame.quit()
                quit()
        
            
        
        
        screen.blit(menuback, (0, 0))
        if Choice == "0":
            button("START",200,450,700,50,green,bright_green,Choice, "play",)                                               
            button("EXIT",200,550,700,50,red,bright_red,Choice, "quit",)
        if Choice == "1":
            button("1 PLAYER",200,450,700,50,green,bright_green,Choice, "play")                                               
            button("2 PLAYER",200,550,700,50,red,bright_red,Choice, "quit")
        if Choice == "2":
            button("STORY MODE",200,450,700,50,green,bright_green,Choice, "play")                                               
            button("vs CPU",200,550,700,50,red,bright_red,Choice, "quit")
        
        
        pygame.display.update()
        updater.tick(15)

#This block of code creates a function, main(). Inside this function, a variable intro, is set to the boolean value of True and while this value is true, the loop
#runs. The while loop first contains a nested for loop, (for event in pygame.event.get():, which contains an if statement for confirming if user wants to quit or exit.
#Outside the for loop and back into the while loop, we have the rendering phase. In this rendering phase, all of our designs, colours, text are printed or drawn onto
#our pygame screen. For example, screen.blit(menuback, (0,0)) prints the background picture we assigned to variable menuback a couple codes back, and it is assigned
#to positions 0,0. These positions are basically the top left corner, which is where our background initializes from. To continue, our start button and exit button is
#designed with the colour variables we assigned earlier in the code. Then, pygame.display.update() function is called. If we imagine pygame like a flip book, than this
#function would constantly keep flipping our pages. Last but not least, the main menu is locked onto 15 frames per second, by the updater.tick function.
#____________________________________________________________________________________________________________________________________________________________________
        




background_music = pygame.mixer.music.load("background.mp3")
pygame.mixer.music.play() 
while game: 
    main()
#This brings us to our last block of code. In this last section, we first create a variable background_music which loads mp3 file background,
#which is then executed/played by the pygame.mixer.music.play() function. Last but not least, while the variable game, which was the first thing we assigned, is true,
#which it always is, the main game function is executed. This allows our main menu to function.    
    

