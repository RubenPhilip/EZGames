#Talha Ali
#Jan 18th 2019
#ICS4U
#Chapter 2 in story
import pygame
from pygame.locals import *
import os
def main():
    pygame.init()                                                                      
    pygame.display.init()
    
    screensize = (798, 459)

    screen = pygame.display.set_mode((screensize))                                                      

    clock = pygame.time.Clock()
    
    pygame.display.set_caption("Karius's Redemption")
    
    ball = pygame.image.load("download.jpg")
    
    background = pygame.image.load("Story25.png")
    with open("Store.txt", "w") as file:
        file.write("2")

    
    story = 0
    pygame.display.set_icon(ball)
    running = True
    while running:                                                          
        clock.tick(64)
        for event in pygame.event.get():                                        
            if event.type == QUIT:                                                
                pygame.quit()
                running = False
        story += 1
        if story == 150:
            background = pygame.image.load("Story26.png")
        elif story == 450:
            background = pygame.image.load("Story27.png")
        elif story == 500:
            background = pygame.image.load("Story28.png")
        elif story == 550:
            background = pygame.image.load("Story29.png")
        elif story == 600:
            background = pygame.image.load("Story30.png")
        elif story == 650:
            background = pygame.image.load("Story31.png")
        elif story == 700:
            background = pygame.image.load("Story32.png")
        elif story == 750:
            background = pygame.image.load("Story33.png")
        elif story == 800:
            background = pygame.image.load("Story34.png")
        elif story == 1100:
            background = pygame.image.load("Story35.png")
        elif story == 1225:
            background = pygame.image.load("Story36.png")
        elif story == 1500:
            background = pygame.image.load("Story37.png")
        elif story == 1700:
            background = pygame.image.load("Story38.png")
        elif story == 1900:
            import Error_fix

            
            
        screen.blit(background, (0, 0))
        pygame.display.flip()
        
    pygame.quit()                                                                       
    pygame.display.quit()
    
    
main()
            
