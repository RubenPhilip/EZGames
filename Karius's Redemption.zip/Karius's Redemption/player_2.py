#Talha Ali
#January 18th 2019
#ICS4U
#This program codes the two player game Karius's Redmeption. It follows the same algorithms as the single player game
#however new file had to be created in order to make the opposing team goalkeeper move in response to different key strokes. Otherwise
#it would move according to where the location of the ball is. 
import random
import pygame
from pygame.locals import *
import sys


    
class Pong(object):
    
    def __init__(self, screensize):


        self.screensize = screensize
        
        self.centerx = int(screensize[0]*random.choice((0.1, 0.5)))                                         
        self.centery = int(screensize[1]*random.choice((0.1, 0.9)))                                       
    
        
        
        self.radius = 8                                                                                   

        self.rect = pygame.Rect(self.centerx-self.radius,
                                self.centery-self.radius,
                                self.radius*2, self.radius*2)                                                     
        self.color = (100,100,255)


        self.direction = [1,0.5]                                              

        self.speedx = 3
        self.speedy = 5
        

        self.hit_edge_left= False
        self.hit_edge_right= False

    def update(self, karius, bale, defender, attacker, attacker_1, defender_1, defender_2, defender_3, wait, hard):
        global collision
        
        self.centerx += self.direction [0]*self.speedx
        self.centery += self.direction [1]*self.speedy

        self.rect.center = (self.centerx, self.centery)
        
        if self.rect.top <= 0:
            self.direction[1] = 1
        elif self.rect.bottom >= self.screensize[1]-1:
            self.direction[1] = -1
            
        if self.rect.right >= self.screensize[0]-1:
            self.hit_edge_right = True
        elif self.rect.left <= 0:
            self.hit_edge_left = True

        
        
        if self.rect.colliderect(karius.rect):
            self.direction[0] = -1
            self.direction[1]= random.choice((-5,-4,-3,-2,-1,1,2,3,4,5))
            #self.speedx=0.01
            commentary_number=random.randint(1,5)
            if commentary_number == 1:
                pygame.mixer.music.load("martin_tyler.mp3")
                pygame.mixer.music.play()
            elif commentary_number == 2:
                self.music=pygame.mixer.music.load("save of the season.mp3")
                pygame.mixer.music.play()
            elif commentary_number == 3:
                self.music=pygame.mixer.music.load("stellar save.mp3")
                pygame.mixer.music.play()
            elif commentary_number == 4:
                self.music=pygame.mixer.music.load("amazing save.mp3")
                pygame.mixer.music.play()
            elif commentary_number == 5:
                self.music=pygame.mixer.music.load("spectacular save.mp3")
                pygame.mixer.music.play()

        if self.rect.colliderect(bale.rect):
            self.direction[0] = 1 #9,10 for hard
            self.direction[1]= random.choice((-5,-4,-3,-2,-1,1,2,3,4,5)) #1,-1 for hard
            self.speedx = 1
        if wait < 15:
            if self.rect.colliderect(attacker.rect):
                if attacker_1.centery >= int(534*0.5):
                    self.direction[0] = 1
                    self.direction[1]= random.choice((-0.5, -0.4, -0.3, -0.2, -0.1))
                    self.speedx= 6
                elif attacker_1.centery <= int(534*0.5):
                    self.direction[0] = 1
                    self.direction[1]= random.choice((0.5, 0.4, 0.3, 0.2, 0.1))
                    self.speedx= 6
                
    
            if self.rect.colliderect(attacker_1.rect):
                if attacker_1.centery >= int(534*0.5):
                    self.direction[0] = -1
                    self.direction[1]= random.choice((-0.5, -0.4, -0.3, -0.2, -0.1))
                    self.speedx= 6
                elif attacker_1.centery <= int(534*0.5):
                    self.direction[0] = -1
                    self.direction[1]= random.choice((0.5, 0.4, 0.3, 0.2, 0.1))
                    self.speedx= 6
        else:
            "do nothing, to make it harder you can do random (1 or 2) if 2 it only skips your attackers collision so they always shoot at you"
           
        if self.rect.colliderect(defender) or self.rect.colliderect(defender_3):
            self.speedx= 0.5
            if self.rect.colliderect(defender):
                self.direction[0]=1
            elif self.rect.colliderect(defender_3):
                self.direction[0]=-1
            
            self.direction[1] = 1
        if self.rect.colliderect(defender_1) or self.rect.colliderect(defender_2):
            self.speedx= 0.58
            self.direction[0]=-self.direction[0]
            self.direction[1] = -1
            if self.rect.colliderect(defender_1):
                self.direction[0]=1
            elif self.rect.colliderect(defender_2):
                self.direction[0]=-1
        
            
        
    def render(self, screen):
        pygame.draw.circle(screen, self.color, self.rect.center, self.radius, 0)
        pygame.draw.circle(screen, (0,0,0), self.rect.center, self.radius, 1)
         
class Bale(object):
    def __init__ (self, screensize):
        self.screensize = screensize

        self.centerx = 15
        self.centery = int(screensize[1]*0.5)
        
        self.height =  25
        
        self.width = 10

        self.item = pygame.image.load("attacker.png")

        self.rect = pygame.Rect(0, self.centery-int(self.height*0.5), self.width, self.height)

        self.color = (255, 100, 100)

        self.speed = 7

    def update(self, pong):
        if pong.rect.top < self.rect.top:
            self.centery -= self.speed
            #if self.centery > self.speed:  #Not needed right now
                #self.item = pygame.image.load("attackerup.png")
        elif pong.rect.bottom > self.rect.bottom:
            self.centery += self.speed

        self.rect.center = (self.centerx, self.centery)

    def render(self, screen):
        screen.blit(self.item, self.rect)

class Player():
    def __init__ (self, screensize):
        self.item = pygame.image.load("attacker.png")
        
        self.screensize = screensize
        
        self.centerx = 5
        self.centery = int(screensize[1]*0.5)
        
        self.height =  50
        
        self.width = 20


        self.rect = pygame.Rect(0, self.centery-int(self.height*0.5), self.width, self.height)

        self.color = (255, 100, 100)

        self.speed = 3
        self.direction = 0
    

    def update(self):
        self.centery += self.direction*self.speed
        self.rect.center = (self.centerx, self.centery)
        if self.rect.top < 0:
            self.rect.top = 0
        if self.rect.bottom > self.screensize[1]-1:
            self.rect.bottom = self.screensize[1]-1

    def render(self, screen):
        screen.blit(self.item, self.rect)

class Defender(Bale):
    def __init__(self, screensize):
        super().__init__(screensize)
        self.centerx = 400
        self.centery = int(screensize[1]*0.05)
        self.speed = 11
    
    def update(self, pong):
        if self.centerx >= 445:
            self.centerx -= self.speed
        elif pong.centerx < self.centerx:
            self.centerx -= self.speed
            #if self.centery > self.speed:  #Not needed right now
                #self.item = pygame.image.load("attackerup.png")
        elif pong.rect.x > self.centerx:
            self.centerx += self.speed
            

        self.rect.center = (self.centerx, self.centery)

class Defender_1(Bale):
    def __init__(self, screensize):
        super().__init__(screensize)
        self.centerx = 400
        self.centery = int(screensize[1]*0.9)
        self.speed = 11
    
    def update(self, pong):
        if self.centerx >= 445:
            self.centerx -= self.speed
        elif pong.centerx < self.centerx:
            self.centerx -= self.speed
            #if self.centery > self.speed:  #Not needed right now
                #self.item = pygame.image.load("attackerup.png")
        elif pong.rect.x > self.centerx:
            self.centerx += self.speed
            

        self.rect.center = (self.centerx, self.centery)

class Defender_2(Bale):
    def __init__(self, screensize):
        super().__init__(screensize)
        self.centerx = 500
        self.centery = int(screensize[1]*0.9)
        self.speed = 11
        self.item = pygame.image.load("team.png")
    
    def update(self, pong):
        if self.centerx <= 431:
            self.centerx += self.speed
        elif pong.centerx < self.centerx:
            self.centerx -= self.speed
            #if self.centery > self.speed:  #Not needed right now
                #self.item = pygame.image.load("attackerup.png")
        elif pong.rect.x > self.centerx:
            self.centerx += self.speed
            

        self.rect.center = (self.centerx, self.centery)

class Defender_3(Bale):
    def __init__(self, screensize):
        super().__init__(screensize)
        self.centerx = 500
        self.centery = int(screensize[1]*0.05)
        self.speed = 11
        self.item = pygame.image.load("team1.png")
    
    def update(self, pong):
        if self.centerx <= 431:
            self.centerx += self.speed
        elif pong.centerx < self.centerx:
            self.centerx -= self.speed
            #if self.centery > self.speed:  #Not needed right now
                #self.item = pygame.image.load("attackerup.png")
        elif pong.rect.x > self.centerx:
            self.centerx += self.speed
            

        self.rect.center = (self.centerx, self.centery)
class Attacker(Bale):
    def __init__(self, screensize):
        super().__init__(screensize)
        self.centerx = 400
        self.centery = int(screensize[1]*0.3)
        self.speed = 3

class Attacker_1(Bale):
    def __init__(self, screensize):
        super().__init__(screensize)
        self.centerx = 500
        self.speed = 3
        self.item = pygame.image.load("team1.png")

        
class Karius(object):
    def __init__ (self, screensize):

        self.item = pygame.image.load("goalkeeper.png")
        
        self.screensize = screensize

        self.centerx = screensize[0]-35
        self.centery = int(screensize[1]*0.5)
        
        self.height =  35
        self.width = 10

        self.rect = pygame.Rect(0, self.centery-int(self.height*0.5), self.width, self.height)

        self.color = (100, 255, 100)

        self.speed = 3
        self.direction = 0
    

    def update(self):
        self.centery += self.direction*self.speed

        self.rect.center = (self.centerx, self.centery)
        if self.rect.top < 0:
            self.rect.top = 0
        if self.rect.bottom > self.screensize[1]-1:
            self.rect.bottom = self.screensize[1]-1

    def render(self, screen):
        screen.blit(self.item, self.rect)


        
def main():                                               
                                                                               
    pygame.init()                                                                      
    pygame.display.init()
    
    screensize = (878, 534)

    screen = pygame.display.set_mode((screensize))                                                      

    clock = pygame.time.Clock()                                                             

    font = pygame.font.SysFont("Impact", 20)

    saves = 0

    pygame.display.set_caption("Karius's Redemption")

    ball = pygame.image.load("download.jpg")

    background = pygame.image.load("footballfield.jpg")

    pygame.display.set_icon(ball)

    wait = 0
    hard = 0
    karius_wins=0
    bale_wins=0
    restart_loop=True
    time=float(90)
    extra_time=0
    extra_time_tracker=0
    last_game = font.render("Last Winner: ---", True, (0, 0, 0))
    while restart_loop:
        pong = Pong(screensize)
        bale = Player(screensize)
        karius = Karius(screensize)
        defender = Defender(screensize)
        defender_1 = Defender_1(screensize)
        defender_2 = Defender_2(screensize)
        defender_3 = Defender_3(screensize)
        attacker = Attacker(screensize)
        attacker_1 = Attacker_1(screensize)
        who_won=0
        if time<=0:
            if bale_wins>karius_wins:
                who_won=1
                
            elif karius_wins>bale_wins:
                who_won=2
                
            else:
                if extra_time_tracker>0:
                    if extra_time==1:
                        extra_time=extra_time+1
                        time=time+30
                    elif extra_time>1:
                        who_won=3
        
        status='Shameful and Level: Easy'
        running = True                                                           
        while running:                                                          
            clock.tick(64)                                                          
                                                                                     
            for event in pygame.event.get():
                if event.type == QUIT:
                    pygame.quit()
                    running = False
                if event.type == KEYDOWN:
                    if event.key == K_UP:
                        karius.direction = -1
                        karius.item = pygame.image.load("saving.png")
                    elif event.key == K_DOWN:
                        karius.direction = 1
                        karius.item = pygame.image.load("saving_down.png")
                    elif event.key == K_w:
                        bale.direction = -1
                        bale.item = pygame.image.load("attackerup.png")
                    elif event.key == K_s:
                        bale.direction = 1
                        bale.item = pygame.image.load("attackerdown.png")
                elif event.type == KEYUP:
                    if event.key == K_UP and karius.direction == -1:
                        karius.direction = 0
                        karius.item = pygame.image.load("goalkeeper.png")
                    elif event.key == K_DOWN and karius.direction == 1:
                        karius.direction = 0
                        karius.item = pygame.image.load("goalkeeper.png")
                    if event.key == K_w and bale.direction == -1:
                        bale.direction = 0
                        bale.item = pygame.image.load("attacker.png")
                    elif event.key == K_s and bale.direction == 1:
                        bale.direction = 0
                        bale.item = pygame.image.load("attacker.png")
                        

          
                
                
            bale.update()
            defender.update(pong)
            defender_1.update(pong)
            defender_2.update(pong)
            defender_3.update(pong)
            attacker.update(pong)
            attacker_1.update(pong)
            karius.update()
            pong.update(karius, bale, defender, attacker, attacker_1, defender_1, defender_2, defender_3, wait, hard)                                                         
           
            if pong.hit_edge_left:
                karius_wins=karius_wins+1
                running=False
            elif pong.hit_edge_right:
                bale_wins=bale_wins+1
                running=False
            elif pong.rect.colliderect(attacker_1.rect) or pong.rect.colliderect(attacker.rect):
                wait+=1
                if wait>= 20:
                    wait=0
            else:
                time=time-0.01
                if time<=0:
                    extra_time_tracker=extra_time_tracker+1
                    extra_time=extra_time+1
                    running=False
            
            
                
           
            
            score = font.render("Real Madrid "+str(bale_wins) + "-" + str(karius_wins)+" Liverpool", True, (0, 0, 0))
            time_left = font.render("Time Remaining:  "+str(int(time)), True, (0, 0, 0))

            if who_won == 1:
                font = pygame.font.SysFont("Impact", 20)
                last_game = font.render("Last Winner: Real Madrid", True, (0, 0, 0))
                time=90
                karius_wins=0
                bale_wins=0
                extra_time=0
                extra_time_tracker=0
                running = False
            elif who_won ==2:
                font = pygame.font.SysFont("Impact", 20)
                last_game = font.render("Last Winner: Liverpool", True, (0, 0, 0))
                time=90
                karius_wins=0
                bale_wins=0
                extra_time=0
                extra_time_tracker=0
                running = False
            elif who_won ==3:
                font = pygame.font.SysFont("Impact", 20)
                last_game = font.render("Last Winner: TIE GAME", True, (0, 0, 0))
                time=90
                karius_wins=0
                bale_wins=0
                extra_time=0
                extra_time_tracker=0
                running = False
            
            
            screen.fill((100,100,100))
            screen.blit(background, (0, 0))
            screen.blit(score, (200,10))
            screen.blit(time_left, (0,10))
            screen.blit(last_game, (600,10))

            

            bale.render(screen)
            defender.render(screen)
            defender_1.render(screen)
            defender_2.render(screen)
            defender_3.render(screen)
            attacker.render(screen)
            attacker_1.render(screen)
            karius.render(screen)
            pong.render(screen)
            
            pygame.display.flip()                                                               
        
    
    pygame.quit()                                                                       
    pygame.display.quit() 

main()
            
