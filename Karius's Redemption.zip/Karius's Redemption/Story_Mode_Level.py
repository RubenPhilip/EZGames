#Talha Ali
#Jan 18th 2019
#ICS4U
#Begins the story mode
import pygame
from pygame.locals import *
import os
def main():
    pygame.init()                                                                      
    pygame.display.init()
    
    screensize = (798, 459)

    screen = pygame.display.set_mode((screensize))                                                      

    clock = pygame.time.Clock()
    
    pygame.display.set_caption("Karius's Redemption")
    
    ball = pygame.image.load("download.jpg")
    
    background = pygame.image.load("Story17.png")
    with open("Store.txt", "w") as file:#Opens file in the mode, writing
        file.write("1")
    #It writes to an external file in order for the game to know which level the user is on. This story corresponds to level 1.
#______________________________________________________________________________________________________________________________________________________
               
                   

    story = 0
    pygame.display.set_icon(ball)
    running = True
    while running:                                                          
        clock.tick(64)
        for event in pygame.event.get():                                        
            if event.type == QUIT:                                                
                pygame.quit()
                running = False
        story += 1
        if story == 150:
            background = pygame.image.load("Story18.png")
        elif story == 250:
            background = pygame.image.load("Story19.png")
        elif story == 425:
            background = pygame.image.load("Story20.png")
        elif story == 500:
            background = pygame.image.load("Story21.png")
        elif story == 550:
            background = pygame.image.load("Story22.png")
        elif story == 800:
            background = pygame.image.load("Story23.png")
        elif story == 1200:
            background = pygame.image.load("Story24.png")
        elif story == 1300:
            import Story_full
            
        #As time goes on, the picture on the screen changes, making the game look like it was animated
            
            
        screen.blit(background, (0, 0))
        pygame.display.flip()
        
    pygame.quit()                                                                       
    pygame.display.quit()
    
    
main()
            
