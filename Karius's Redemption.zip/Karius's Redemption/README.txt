Talha Ali

ICS3UR

June 18, 2018

Version
2.3

Game Description - 
1)Karius�s Redemption includes a goalkeeper, Karius, that is trying to prevent a soccer ball from going into his net. The more amazing saves he makes, the higher his
status gets. He initially feels shameful but the objective of the game is to win the Ballon D'or.

what is required for the program to run?
2)The Story.py file is the main file, it includes, Karius_redemption.py, Karius_redemption_2.py, Character Choice.py, amazing save.mp3, attacker.png,
attacker_kicking.png, attackerdown.png, attackerup.png, background.mp3, download.jpg, footballfield.jpg, goalkeeper.png, liverpool_won.jpg, MAINMENU.jpg, 
martin_tyler.mp3, save of the season.mp3, saving.png, saving_down.png, spectacular save.mp3, stellar save.mp3. The user must also have the pygame library. There
are more files but the user is able to play single player with these.

3) INSTRUCTIONS:
Click on setup.py. This file will install pygame for the user and run the game. 


