#Talha Ali
#Jan 18th 2019
#ICS4U
#Chapter 3 in story
import pygame
from pygame.locals import *
import os
def main():
    pygame.init()                                                                      
    pygame.display.init()
    
    screensize = (798, 459)

    screen = pygame.display.set_mode((screensize))                                                      

    clock = pygame.time.Clock()
    
    pygame.display.set_caption("Karius's Redemption")
    
    ball = pygame.image.load("download.jpg")
    
    
    background = pygame.image.load("Story25.png")
    
    
    with open("Store.txt", "w") as file:
        file.write("3")


    story = 0
    pygame.display.set_icon(ball)
    running = True
    while running:                                                          
        clock.tick(64)
        for event in pygame.event.get():                                        
            if event.type == QUIT:                                                
                pygame.quit()
                running = False
        story += 1
        if story == 150:
            background = pygame.image.load("Story39.png")
        elif story == 500:
            background = pygame.image.load("Story40.png")
        elif story == 575:
            background = pygame.image.load("Story41.png")
        elif story == 675:
            background = pygame.image.load("Story42.png")
        elif story == 750:
            background = pygame.image.load("Story43.png")
        elif story == 1100:
            background = pygame.image.load("Story24.png")
        elif story == 1300:
            import Story_full
            
            
            
        screen.blit(background, (0, 0))
        pygame.display.flip()
        
    pygame.quit()                                                                       
    pygame.display.quit()
    
    
main()
            
