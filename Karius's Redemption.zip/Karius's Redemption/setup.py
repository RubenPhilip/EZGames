#Talha Ali
#Jan 18th 2019
#ICS4U
#Runs game
import os
import sys

os.system("start cmd /c pip install pygame")
print("Press enter to continue")
input()

try:
    import pygame
    os.startfile('Story.py')
except:
    os.startfile('pygame_install.txt')
